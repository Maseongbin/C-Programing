#include <ros/ros.h>
#include <image_transport/image_transport.h> // ROS에서 이미지 전송을 위한 라이브러리
#include <opencv2/opencv.hpp> // OpenCV 기본 라이브러리
#include <cv_bridge/cv_bridge.h> // ROS 이미지 메시지를 OpenCV 형식으로 변환
#include <std_msgs/Float32.h>
#include <std_msgs/String.h>
#include <math.h>

using namespace cv;
using namespace std;

// ROI(관심 영역)와 관련된 상수 정의
#define ROI_CENTER_Y 120
#define ROI_WIDTH 20
#define NO_LINE 20

// 각도 변환 매크로
#define DEG2RAD(x) (M_PI/180.0)*x
#define RAD2DEG(x) (180.0/M_PI)*x

// 전역 변수 선언
Mat cv_image; // ROS 이미지 데이터를 저장할 변수

int img_width = 320;
int img_height = 240;

Mat mat_image_org_color; // 원본 컬러 이미지
Mat mat_image_org_gray; // 그레이스케일 이미지
Mat mat_image_roi; // 관심 영역(ROI) 이미지
Mat mat_image_canny_edge; // Canny Edge 검출 이미지
Mat mat_image_canny_edge_roi; // ROI 내에서 Canny Edge 검출 이미지

int m_roi_center = 120; // ROI의 중심
int m_roi_height = 20; // ROI의 높이
int m_roi_width = 320; // ROI의 너비
int m_roi_width_large = 3; // ROI의 확장된 너비

float line_center_x = 0.0;
float line_center_x_old = 0.0;

// 사각형 영역을 나타내는 구조체
struct Rect_Region
{
    int left;
    int right;
    int top;
    int bottom;
};

// ROI에서 검출된 선의 중심 위치를 나타내는 구조체
struct Rect_Region ROI_line_center;

// 관심 영역을 잘라내는 함수
Mat Region_of_Interest_crop(Mat image, Point *points)
{
    Mat img_roi_crop;
    // 이미지 경계를 계산하여 초과하지 않도록 함
    Rect bounds(0, 0, image.cols, image.rows);
    Rect r(points[0].x, points[0].y, points[2].x - points[0].x, points[2].y - points[0].y);
    img_roi_crop = image(r & bounds); // 관심 영역 자르기
    return img_roi_crop;
}

// Canny Edge Detection 함수
Mat Canny_Edge_Detection(Mat img)
{
    Mat mat_blur_img, mat_canny_img;
    // 블러를 통해 노이즈 제거
    blur(img, mat_blur_img, Size(3, 3));
    // Canny 알고리즘을 통해 엣지 검출
    Canny(mat_blur_img, mat_canny_img, 70, 150, 3);
    return mat_canny_img;
}

// 카메라 이미지 콜백 함수, 새로운 이미지가 수신될 때마다 호출
void imageCallback(const sensor_msgs::ImageConstPtr& msg)
{
    // ROS 이미지 메시지를 OpenCV 이미지로 변환
    cv_image = cv_bridge::toCvShare(msg, "bgr8")->image;
    img_width = cv_image.size().width;
    img_height = cv_image.size().height;
    
    // 원본 이미지를 복사
    mat_image_org_color = cv_image.clone();
    
    // 컬러 이미지를 그레이스케일로 변환
    cvtColor(mat_image_org_color, mat_image_org_gray, COLOR_BGR2GRAY);
    
    // 관심 영역의 네 꼭지점 좌표 정의
    Point points[4];
    points[0] = Point(img_width/2 - m_roi_width, m_roi_center - m_roi_height);
    points[1] = Point(img_width/2 - m_roi_width, m_roi_center + m_roi_height);
    points[2] = Point(img_width/2 + m_roi_width, m_roi_center + m_roi_height);
    points[3] = Point(img_width/2 + m_roi_width, m_roi_center - m_roi_height);
    
    // 관심 영역을 잘라내기
    // mat_image_roi = Region_of_Interest_crop(mat_image_org_gray, points); // 그레이스케일 사용 시
    mat_image_roi = Region_of_Interest_crop(mat_image_org_color, points); // 컬러 이미지 사용
    
    // Canny Edge 검출 실행
    mat_image_canny_edge = Canny_Edge_Detection(mat_image_roi);
    
    // 원본 이미지에 관심 영역을 사각형으로 표시
    rectangle(mat_image_org_color, points[0], points[2], Scalar(0, 255, 0), 2);
    
    // 결과 이미지를 화면에 출력
    imshow("Original Image", mat_image_org_color);
    imshow("ROI", mat_image_roi);
    // imshow("Canny Edge", mat_image_canny_edge); // 필요 시 Canny Edge 이미지 출력
    
    // 사용자 키 입력 대기
    waitKey(1);
}

int main(int argc, char **argv)
{
    // ROS 노드 초기화
    ros::init(argc, argv, "opencv_lane_detection_node");
    ros::NodeHandle nh;
    
    // 카메라 토픽 설정
    std::string camera_topic = "/camera/image_raw";
    
    // 파라미터 서버에서 값 읽기
	ros::param::get("~camera_topic", camera_topic);
	ros::param::get("~m_roi_center", m_roi_center);
	ros::param::get("~m_roi_height", m_roi_height);
	ros::param::get("~m_roi_width", m_roi_width);
	ros::param::get("~img_width", img_width);
	ros::param::get("~img_height", img_height);
	
    // 이미지 수신을 위한 이미지 트랜스포트 객체 생성
    image_transport::ImageTransport it(nh);
    // 이미지 구독자 설정
    image_transport::Subscriber sub = it.subscribe(camera_topic, 10, imageCallback);
    
    // 루프 주기 설정 (30Hz)
    ros::Rate rate(30);
    while (ros::ok())
    {
        // 콜백 함수 호출
        ros::spinOnce();
        rate.sleep(); // 설정된 주기로 대기
    }
    
    return 0;
}
